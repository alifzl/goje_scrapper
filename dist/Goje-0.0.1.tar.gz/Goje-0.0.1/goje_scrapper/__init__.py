from .goje import Goje
from .goje import GojeScraper